let datos = [
    {
        nombre:"Specialiced XX",
        descripcion:"Bicicleta gravel Acero con componentes sram nx",
        precio:1150,
        imagen:"http://api.raulserranoweb.es/imagenes_art/1"
    },
    {
        nombre:"Specialiced 2",
        descripcion:"Bicicleta gravel aluminio con componentes sram nx",
        precio:1350,
        imagen:"http://api.raulserranoweb.es/imagenes_art/2"
    },
    {
        nombre:"specialized 3",
        descripcion:"specialiced allez de aluminio , SRAM",
        precio:2250,
        imagen:"http://api.raulserranoweb.es/imagenes_art/3"
    },
    {
        nombre:"specialized 4",
        descripcion:"specialized modelo dolce de carbono, comp. shimano",
        precio:1950,
        imagen:"http://api.raulserranoweb.es/imagenes_art/9"
    },
    {
        nombre:"specialized 5",
        descripcion:"specialized carretera carbono, comp shimano deore",
        precio:2300,
        imagen:"http://api.raulserranoweb.es/imagenes_art/5"
    },
    {
        nombre:"specialized 6",
        descripcion:"specialized de carretera, carbono, shimano ultegra",
        precio:2150,
        imagen:"http://api.raulserranoweb.es/imagenes_art/9"
    },
    {
        nombre:"specialized 7",
        descripcion:"specialized vengue, carbono, SRAM RED Tap",
        precio:3550,
        imagen:"http://api.raulserranoweb.es/imagenes_art/7"
    },
    {
        nombre:"specialized 8",
        descripcion:"Bicicleta de Gravel, aluminio",
        precio:3300,
        imagen:"http://api.raulserranoweb.es/imagenes_art/8"
    }

]